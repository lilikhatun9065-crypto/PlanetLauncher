PLANET LAUNCHER — Android project

যা আছে:
- Android Home/Default Launcher intent
- ইনস্টল করা launchable অ্যাপের আইকন স্বয়ংক্রিয়ভাবে সংগ্রহ
- গোলকের গায়ে Fibonacci sphere বিন্যাসে আইকন
- টাচ ড্র্যাগে ঘোরানো, inertia, ট্যাপ করে অ্যাপ চালু
- নাম দিয়ে অ্যাপ ফিল্টার করার সার্চ

বিল্ড:
1) AndroidIDE বা Android Studio-তে PlanetLauncher ফোল্ডারটি Open Project করুন।
2) Gradle sync সম্পন্ন হতে দিন (AGP 8.6.1, compileSdk 35, JDK 17 প্রয়োজন)।
3) app > assembleDebug চালান।
4) app/build/outputs/apk/debug/app-debug.apk ইনস্টল করুন।
5) Home চাপলে Planet Launcher নির্বাচন করুন; চাইলে Always দিন।

নোট:
- QUERY_ALL_PACKAGES পারমিশন ব্যবহার করা হয়েছে, যাতে ডিভাইসের সব launchable অ্যাপ দেখানো যায়। Play Store-এ এই পারমিশনের ব্যবহার সীমাবদ্ধ; ব্যক্তিগত sideload ব্যবহারের জন্য প্রকল্পটি সাজানো।
- এই পরিবেশে Android SDK দিয়ে APK compile/test করা হয়নি; এটি সোর্স প্রজেক্ট ZIP।
- কিছু সিস্টেম/প্রাইভেট অ্যাপের launcher activity না থাকলে সেগুলো তালিকায় আসবে না।
